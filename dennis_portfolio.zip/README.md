# Dennis De Jesus | Professional Portfolio

This is the professional portfolio of **Dennis De Jesus**, built with Tailwind CSS and Font Awesome.

## Features
- Contact information and downloadable resume
- Professional summary
- Technical capabilities (Typing, Internet, Computer Specs)
- Home office setup showcase

Deployed for public viewing on GitHub Pages.
